#00001 is the orthologous gene id
paml_branch-site_analysis.pl   orthologGroups00001.CDS.formated.phy  tree.txt  branch-site_model/00001 > branch-site_model/00001/paml_BS_pvalue.txt