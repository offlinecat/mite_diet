#!/usr/bin/perl
#use strict;
#use Getopt::Long;

my $usage = <<USAGE;
Usage:
 
  perl  $0 [options] input.phy input.tree out_dir > p_value.txt

USAGE
if (@ARGV==0){die $usage};

# 准备程序的中间文件夹和文件
 unless (-e $ARGV[2]) {
	 mkdir $ARGV[2] or die "Can not create directory $ARGV[2], $!";
   	 }
 unless (-e "$ARGV[2]/runA") {
         mkdir "$ARGV[2]/runA" or die "Can not create directory $ARGV[2]/runA, $!";
         }
 unless (-e "$ARGV[2]/runAm") {
         mkdir "$ARGV[2]/runAm" or die "Can not create directory $ARGV[2]/runAm, $!";
         }



# 生成codeml的输入文件input.tree
`cp $ARGV[1] $ARGV[2]/runA/input.tree ` ;
`cp $ARGV[1] $ARGV[2]/runAm/input.tree` ;

#生成codeml的输入文件input.phy
`cp $ARGV[0] $ARGV[2]/runA/input.phy ` ;
`cp $ARGV[0] $ARGV[2]/runAm/input.phy ` ;

#生成codeml的配置文件codeml.ctl
open OUT0, ">", "$ARGV[2]/runA/codeml.ctl" or die "Can not create file $ARGV[2]/runA/codeml.ctl, $!";
open OUT1, ">", "$ARGV[2]/runAm/codeml.ctl" or die "Can not create file $ARGV[2]/runAm/codeml.ctl, $!";
my $out = "      seqfile = input.phy
     treefile = input.tree
      outfile = mlc
        noisy = 3
      verbose = 1
      runmode = 0
      seqtype = 1
    CodonFreq = 2
        clock = 0
        model = 2
      NSsites = 2
        icode = 0
    fix_kappa = 0
        kappa = 2.5
    fix_omega = 0
        omega = 2
    fix_alpha = 1
        alpha = 0
       Malpha = 0
        ncatG = 10
        getSE = 0
 RateAncestor = 0
  *     method = 0
	cleandata = 1
  fix_blength = 0\n";
print OUT0 $out;
$out =~ s/fix_omega = 0/fix_omega = 1/;
$out =~ s/omega = 2/omega = 1/;
print OUT1 $out;
close OUT0; close OUT1;
chdir $ARGV[2];
open OUT, ">", "command.codeml.list" or die "Can not create file $ARGV[2]/command.codeml.list, $!";
print OUT "cd runA; codeml codeml.ctl &> codeml.log\ncd runAm; codeml codeml.ctl &> codeml.log\n";
close OUT;
my $cmdString = 'ParaFly -c command.codeml.list -CPU 2 &> /dev/null';
(system $cmdString) == 0 or die "Failed to execute: $cmdString, $!";




my ($lnL_value0, $lnL_value1);
open IN, "runA/mlc" or die "Can not open file $ARGV[2]/runA/mlc, $!";
my ($BEB_Significance, $BEB_start) = ("BEB_Significance_NO", 0);
while (<IN>) {
    if (m/^lnL.*:\s*([\d.-]+)/) {
        $lnL_value0 = $1;
	#print STDERR "$lnL_value0\n"; 
    }
    if (m/Bayes Empirical Bayes \(BEB\) analysis/) {
        <IN>; <IN>;
        $BEB_start = 1;
    }
    if ($BEB_start == 1) {
        $BEB_Significance = "BEB_Significance_YES" if m/\*/;
    }
}
close IN;
open IN, "runAm/mlc" or die "Can not open file $ARGV[2]/runAm/mlc, $!";
while (<IN>) {
    if (m/^lnL.*:\s*([\d.-]+)/) {
        $lnL_value1 = $1;
        #print STDERR "$lnL_value1\n";
    }
}
close IN;

my $two_fold_delta_L = abs($lnL_value1 - $lnL_value0) * 2;
$cmdString = "chi2 1 $two_fold_delta_L";
#print STDERR "CMD: $cmdString\n";
my $p_value = `$cmdString`;
$p_value =~ s/.*=\s*//s;
$p_value =~ s/\s*$//;
$p_value = $p_value / 2;
my $outid=`basename $ARGV[2]`;
$outid =~ s/\n//g;
print "$outid\t$p_value\t$BEB_Significance\n";


