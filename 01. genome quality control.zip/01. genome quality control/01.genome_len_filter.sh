#genome_qc,filter the contig less than 1000bp

module load python/2.7.13
seq_tool.py len-filter -i genomic.fna -l 1000 -o genome.over1k.fasta
less genome.over1k.fasta |perl -e 'while(<>){chomp;if(/\>/){@inf=split /\s+/;print "$inf[0]\n"}else{print $_,"\n";}}' >src_genome.fasta