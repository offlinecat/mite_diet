#!/bin/env python
import option_helpers as opth


def get_options():
    options = opth.default_option_map_input()
    options['input']['input_name'] = '<busco_file>'
    options['input']['description'] = 'The output from BUSCO conserved single-copy ortholog analysis.'
    options['name'] = {'order': 2,
                       'short': 'n',
                       'long': 'name',
                       'input_name': '<output_name>',
                       'description': 'The name associated with the data. Used as a row name for a table.',
                       'optional': False}
    options['column_header'] = {'order': 3,
                                'short': 'c',
                                'long': 'column_header',
                                'input_name': None,
                                'description': 'Print the column headers.',
                                'optional': True}
    return options


def parse_white_space(file_handle):
    line = file_handle.readline().strip()
    while len(line) == 0:
        line = file_handle.readline().strip()
    return line


def parse_comments(file_handle, start_char='#'):
    line = file_handle.readline().strip()
    comments = []
    while len(line) != 0 and line[0] == start_char:
        comments.append(line)
        line = file_handle.readline().strip()
    return comments, line


def parse_lines(file_handle):
    output_lines = []
    line = file_handle.readline().strip()
    while line:
        output_lines.append(line)
        line = file_handle.readline().strip()
    return output_lines


def main():
    description = 'Parse the output from BUSCO conserved single-copy ortholog analysis.'
    options = get_options()
    print_usage = opth.print_usage_maker(description, options)
    parse_arguments = opth.parse_options_maker(options, print_usage)
    option_map = parse_arguments()

    input_stats_filename = opth.validate_required('input', option_map, print_usage)
    row_name = opth.validate_required('name', option_map, print_usage)
    do_header = opth.has_option('column_header', option_map)

    data_lines = []
    with open(input_stats_filename) as f:
        comments, first_line = parse_comments(f)
        line = parse_white_space(f)

        # parse the relevant data
        line = parse_white_space(f)
        data_lines.append(line)
        next_lines = parse_lines(f)
        data_lines.extend(next_lines)

    # Extract and print the output
    header = ['name', 'complete_genes', 'single', 'duplicate', 'fragment', 'missing', 'total']
    if do_header:
        print '\t'.join(header)
    output_data = [row_name,
                   data_lines[0].split('\t')[0],
                   data_lines[1].split('\t')[0],
                   data_lines[2].split('\t')[0],
                   data_lines[3].split('\t')[0],
                   data_lines[4].split('\t')[0],
                   data_lines[5].split('\t')[0]]
    print '\t'.join(output_data)


if __name__ == '__main__':
    main()
