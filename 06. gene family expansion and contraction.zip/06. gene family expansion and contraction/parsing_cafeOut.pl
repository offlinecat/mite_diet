#!/usr/bin/perl
use strict;
use Getopt::Long;

my $usage = <<USAGE;
Usage:
    $0 [options] caferror_1/cafe_final_report.cafe

    --out_prefix <string>    default: cafe_out
    设置输出文件前缀。默认设置下，程序在当前目录下输出几个文件：
    （1）cafe_out.cafe    对CAFE结果解析后的表格结果文件，和CAFE的输出结果比较像，但给出了每个节点的p值。
    （2）cafe_out.out     输出显著扩张或收缩的基因家族详细信息，是一个表格结果文件，有5列：第一列是节点编号、第二列是节点名称（若对应外部节点，则时外部节点的名称，若时内部节点，则用字符中划线 - 表示）、第三列是祖先节点的基因家族数量、第四列是目标节点的基因家族数量、第五列是p值。
    （3）cafe_out.stats   输出显著扩张或收缩的基因家族数量统计信息，是一个表格结果文件，有4列：第一列是节点编号、第二列是节点名称（若对应外部节点，则时外部节点的名称，若时内部节点，则用字符中划线 - 表示）、第三列是扩张的基因家族数量、第四列是收缩的基因家族数量。

    --p_value <string>    default: 0.01
    设置p值阈值。

USAGE
if (@ARGV==0){die $usage}

my ($out_prefix, $p_value);
GetOptions(
    "out_prefix:s" => \$out_prefix,
    "p_value:f" => \$p_value,
);
$out_prefix ||= "cafe_out";
$p_value ||= 0.01;

open IN, $ARGV[0] or die "Can not open file $ARGV[0], $!";
open CAFE, ">", "$out_prefix.cafe" or die "Can not create file $out_prefix.cafe, $!";
open OUT, ">", "$out_prefix.out" or die "Can not create file $out_prefix.out, $!";
open STATS, ">", "$out_prefix.stats" or die "Can not create file $out_prefix.stats, $!";

# Tree
$_ = <IN>;
print CAFE;

# Lambda
$_ = <IN>;
print CAFE;

# IDs of nodes
$_ = <IN>;
my $line = $_;
print CAFE;
# 解析节点和名称之间的相互对应关系
my %id_of_node = /(\w+?)<(\d+?)>/g;
my @id_of_node = sort keys %id_of_node;
my (%node_of_id, @node_of_id);
foreach (@id_of_node) {
    $node_of_id{$id_of_node{$_}} = $_;
}
# 解析节点和祖先节点的对应关系
my @numbers = m/<(\d+)>/g;
my ($pos, %pos, %ancestor);
foreach (@numbers) {
    $pos ++;
    $pos{$_} = $pos;
    $node_of_id{$_} = "-" unless exists $node_of_id{$_};
}
@node_of_id = sort {$a <=> $b} keys %node_of_id;
foreach my $num (keys %pos) {
    my $string = $line;
    $string =~ s/.*<$num>//;
    my $value = 0;
    while ($value < 1) {
        last unless $string =~ s/(.)//;
        if ($1 eq '(') {
            $value --;
        }
        elsif ($1 eq ')') {
            $value ++;
        }
    }
    if ($string =~ m/<(\d+)>/) {
        $ancestor{$num} = $1;
        #print STDERR "$num\t$1\n";
    }
}

# node order
# 输出基因家族扩张和搜索数量信息
$_ = <IN>;
my @nodes = /(\d+)/g;
print CAFE ("Node_ID\t" . (join "\t", @node_of_id) . "\n");
my @out;
foreach (@node_of_id) {
    push @out, $node_of_id{$_};
}
print CAFE ("Node_Name\t" . (join "\t", @out) . "\n");
# Average expansion rate
$_ = <IN>;
$_ = <IN>;
s/Average Expansion//;
my @aver_expa = m/([\d\.Ee-]+)/g;
my %aver_expa;
foreach (@nodes) { $aver_expa{$_} = shift @aver_expa; }
my $out = "Average Expansion\t";
foreach (@node_of_id) { $out .= "$aver_expa{$_}\t"; }
$out =~ s/\t$/\n/;
print CAFE $out;
# Expansion gene family number
$_ = <IN>;
my @expansion = m/(\d+)/g;
my %expansion;
foreach (@nodes) { $expansion{$_} = shift @expansion; }
$out = "Expansion\t";
foreach (@node_of_id) { $out .= "$expansion{$_}\t"; }
$out =~ s/\t$/\n/;
print CAFE $out;
# No Change
$_ = <IN>;
my @remain = m/(\d+)/g;
my %remain;
foreach (@nodes) { $remain{$_} = shift @remain; }
$out = "Remain\t";
foreach (@node_of_id) { $out .= "$remain{$_}\t"; }
$out =~ s/\t$/\n/;
print CAFE $out;
# Decrease
$_ = <IN>;
my @decrease = m/(\d+)/g;
my %decrease;
foreach (@nodes) { $decrease{$_} = shift @decrease; }
$out = "Decrease\t";
foreach (@node_of_id) { $out .= "$decrease{$_}\t"; }
$out =~ s/\t$/\n/;
print CAFE $out;

# header
$_ = <IN>;
$out = "\nGene_family_ID\tGene_family_size\tP_alue\t";
foreach (@node_of_id) { $out .= "$_\t"; }
$out =~ s/\t$/\n/;
print CAFE $out;
my $out = "Gene_family_ID\tGene_family_size\tP_alue\t";
foreach (@node_of_id) { $out .= "$node_of_id{$_}\t"; }
$out =~ s/\t$/\n/;
print CAFE $out;

my $total_expansion_family_number = 0;
# cafe main out
my (%out_stats, %out_detail_pvalue, %out_detail_familySize);
while (<IN>) {
    @_ = split /\t/;
    print CAFE "$_[0]\t$_[1]\t$_[2]\t";

    my ($family_id, $family_tree, $P_value, $P_values) = @_;
    my @P_values = $P_values =~ m/([\d\.Ee-]+)/g;
    my %P_values;
    foreach (@nodes) { $P_values{$_} = shift @P_values; }
    my $out = "";
    foreach (@node_of_id) { $out .= "$P_values{$_}\t"; }
    $out =~ s/\t$/\n/;
    print CAFE $out;

    if ($P_value <= $p_value) {
        $total_expansion_family_number ++;

        foreach my $id (@node_of_id) {
            my @family_size = &get_family_size($family_tree, $id);
            if ($P_values{$id} <= $p_value) {
                if ($family_size[0] > $family_size[1]) {
                    $out_stats{$id}{"expansion"} ++;
                    $out_detail_pvalue{$id}{"expansion"}{$family_id} = $P_values{$id};
                    $out_detail_familySize{$id}{"expansion"}{$family_id} = "$family_size[1]\t$family_size[0]";
                }
                elsif ($family_size[0] < $family_size[1]) {
                    $out_stats{$id}{"decrease"} ++;
                    $out_detail_pvalue{$id}{"decrease"}{$family_id} = $P_values{$id};
                    $out_detail_familySize{$id}{"decrease"}{$family_id} = "$family_size[1]\t$family_size[0]";
                }
            }
        }
    }
}
close CAFE;

print STATS "Code\tName\tExpansion_num\tDecrease_num\n";
print OUT "Code\tName\tFamilyID\tType\tAncestor_size\tNode_size\tP_value\n";
foreach my $id (@node_of_id) {
	my $expansion_num = $out_stats{$id}{"expansion"};
	my $decrease_num = $out_stats{$id}{"decrease"};
	print STATS "$id\t$node_of_id{$id}\t$expansion_num\t$decrease_num\n";

	my @family_id = sort {$out_detail_pvalue{$id}{"expansion"}{$a} <=> $out_detail_pvalue{$id}{"expansion"}{$b} or $a cmp $b} keys %{$out_detail_pvalue{$id}{"expansion"}};
	foreach (@family_id) {
		print OUT "$id\t$node_of_id{$id}\t$_\tExpansion\t$out_detail_familySize{$id}{'expansion'}{$_}\t$out_detail_pvalue{$id}{'expansion'}{$_}\n";
	}
	@family_id = sort {$out_detail_pvalue{$id}{"decrease"}{$a} <=> $out_detail_pvalue{$id}{"decrease"}{$b} or $a cmp $b} keys %{$out_detail_pvalue{$id}{"decrease"}};
	foreach (@family_id) {
		print OUT "$id\t$node_of_id{$id}\t$_\tContraction\t$out_detail_familySize{$id}{'decrease'}{$_}\t$out_detail_pvalue{$id}{'decrease'}{$_}\n";
	}
}
close STATS;
close OUT;

print STDERR "\nTotal Expansion/Contractions family number (P_value <= $p_value): $total_expansion_family_number\n\n";

sub get_family_size {
    my $family_tree = shift @_;
    my $species = shift @_;
    my $pos = $pos{$species};
    my $ancestor = $ancestor{$species};
    my $pos_ancestor = $pos{$ancestor};
    #print STDERR "$pos\t$pos_ancestor\n";

    my @familySizes = $family_tree =~ m/_(\d+)/g;
    my @out = ($familySizes[$pos - 1], $familySizes[$pos_ancestor - 1]);
    #print STDERR ((join "\t", @out) . "\n");
    return @out;
}
