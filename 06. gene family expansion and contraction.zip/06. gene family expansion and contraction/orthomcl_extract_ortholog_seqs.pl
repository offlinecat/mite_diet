#!/usr/bin/perl
use strict;
use Getopt::Long;

my $usage = <<USAGE;
Usage:
    perl $0 groups.txt compliantFasta

    程序根据OrthoMCL的聚类结果和基因的序列信息，对每个同源基因家族生成一个FASTA文件，将这些Fasta文件以类的名字命名，保存在指定的文件夹下。
    由于输入文件groups.txt中的同源基因类群较多，可以根据需要选择满足目标需求的同源基因。

    --out_directory <string>    default: orthologGroups
    设置输出文件夹的名字。

    --out_tab_for_CAFE <string>
    添加该参数用于输出一个含有目标同源基因类在各物种中基因家族数量信息的表格文件，该文件可用于CAFE软件的输入，进行基因家族扩展和收缩分析。

    --ortholog_picking_config <string>
    设置一个配置文件，设置挑选目标同源基因类的方法。该文件是一个以制表符分割含有两列数据的文本文件，且不能有表头信息：第一列，多个物种名（物种名必须包含在groups.txt文件中）之间以逗号或分号分割；第二列，一个整数，表示上述指定的多个物种中，在目标同源基因类中至少要有该指定数目的同源基因存在；文件可以有行，则表示每行的条件得同时满足。若不设置该参数，则表示不使用该方法进行同源基因类的挑选。不管是否添加该参数，仍然会使用以下几个参数选择同源基因类。

    --species_ratio <float>    default: 1.0
    设置同源基因必须在不小于此比例的物种中出现。默认设置是提取的目标同源基因在所有物种中都存在。

    --single_copy_species_ratio <float>    default: 1.0
    设置同源基因是单拷贝情况的物种比例要>=该设定值。若设置该值为0.3用于提取单拷贝同源基因时，则表示认为只要在30%的物种中表现为单拷贝，则认为其基因为单拷贝同源基因，这样可以得到更多的单拷贝同源基因（不严格的单拷贝同源基因）。若设置该值为1，则表示单拷贝同源基因必须在所有物种中都表现为单拷贝的（严格的单拷贝同源基因）。

    --copy_num <float>    default: 1.0
    对总体上拷贝数不高于该值的同源基因家族进行提取，即在目标同源基因类中，基因数量 <= 所有物种数（这里指compliantFasta文件夹中Fasta文件的数量） * 该值。 若设置该值为1，用于提取严格的单拷贝同源基因家族；若该值大于1，则表示允许同源基因在部分物种中是多拷贝的，但要求该同源基因家族的总数量 <= （物种数 * 该参数值）。此外，若某个物种在目标基因家族中有多个拷贝，则仅选取最长的序列作为代表性序列放入到目标同源基因家族的FASTA文件中。

    --compliantFasta_dir_for_calculating_seq_length <string>    default: None
    程序默认设置下，从compliantFasta输入文件夹中的数据中计算各序列长度。若添加该参数，则从指定的输入文件夹中的数据计算各序列长度。有时候一些基因的蛋白序列长度相等，但其CDS长度不相等；这时，程序分别选取一个基因家族中最长的蛋白序列和最长的CDS序列时，其结果可能不一致，这时，再对蛋白序列数据进行分析时，使用该参数添加CDS的序列信息来计算序列长度，则能保证CDS和Protein选取的基因名一致，有利于生成后续的密码子比对结果。

    --max_seq_length <int>    default: 2000
    若基因家族最短的序列长度大于此值，则过滤该基因家族。推荐设置该值为2000。若序列长度过长，对该同源基因的数据分析会比较耗时耗计算，同时也可能不利于物种树的准确构建（当单个基因长度占所有基因长度总和的比例过高时）。注意，当设置--compliantFasta_dir_for_calculating_seq_length参数为CDS信息文件夹时，其统计的是CDS长度，此处要设置最长CDS的值，而不要是输入的Protein序列的长度阈值。

USAGE
if (@ARGV==0){die $usage}

my ($out_directory, $out_tab_for_CAFE, $ortholog_picking_config, $species_ratio, $single_copy_species_ratio, $copy_num, $max_seq_length, $compliantFasta_dir_for_calculating_seq_length);
GetOptions (
    "out_directory:s" => \$out_directory,
    "out_tab_for_CAFE:s" => \$out_tab_for_CAFE,
    "ortholog_picking_config:s" => \$ortholog_picking_config,
    "species_ratio:f" => \$species_ratio,
    "copy_num:f" => \$copy_num,
    "single_copy_species_ratio:f" => \$single_copy_species_ratio,
    "max_seq_length:i" => \$max_seq_length,
    "compliantFasta_dir_for_calculating_seq_length:s" => \$compliantFasta_dir_for_calculating_seq_length,
);
$out_directory ||= "orthologGroups";
$species_ratio ||= 1;
$single_copy_species_ratio = '0.0' if $single_copy_species_ratio == 0;
$single_copy_species_ratio ||= 1;
$copy_num ||= 1;
$max_seq_length ||= 2000;

unless (-e $out_directory) {
    mkdir $out_directory or die "Can not create file $out_directory, $!";
}

if ($out_tab_for_CAFE) {
    open OUT_CAFE, ">", $out_tab_for_CAFE or die "Can not create file $out_tab_for_CAFE, $!";
    print OUT_CAFE "Description\tID";
}

my %opc;
if ($ortholog_picking_config) {
    open IN, $ortholog_picking_config or die "Can not open file $ortholog_picking_config, $!";
    while (<IN>) {
        chomp;
        @_ = split /\t/, $_;
        $opc{$_[0]} = $_[1];
    }
    close IN;
}

my (%fasta, %seq_length, @species, %species_name);
foreach (<$ARGV[1]/*.fasta>) {
    chomp;
    my $species;
    if (/(\w+).fasta/) { 
        $species = $1;
        push @species, $species;
        $species_name{$species} = 1;
    }

    print STDERR "reading $_\n";
    open IN, $_ or die $!;
    my $seq_id;
    while (<IN>) {
        chomp;
        if (/>(\S+)/) { $seq_id = $1; }
        else {
            $fasta{$species}{$seq_id} .= $_;
            $seq_length{$species}{$seq_id} += length($_);
        }
    }
    close IN;
}
if ($out_tab_for_CAFE) {
    print OUT_CAFE ("\t" . (join "\t", @species) . "\n");
}

my $species_num = @species;
print STDERR "total $species_num species\nSpecies\t#_Gene\tN50_length\tMedian_length\n";
my @out_species;
foreach my $sp (sort keys %seq_length) {
	my @seq_id = keys %{$seq_length{$sp}};
	my $seq_id_num = @seq_id;
	my (@lengths, $len_n50, $len_median, $total_length);
	foreach (@seq_id) {
		push @lengths, $seq_length{$sp}{$_};
		$total_length += $seq_length{$sp}{$_};
	}
	@lengths = sort {$b <=> $a} @lengths;
	$len_median = $lengths[@lengths/2];
	my $tmp_length;
	foreach (@lengths) {
		$tmp_length += $_;
		if ($tmp_length >= $total_length / 2) {
			$len_n50 = $_;
			last;
		}
	}
	print STDERR "$sp\t$seq_id_num\t$len_n50\t$len_median\n";
}

if ($compliantFasta_dir_for_calculating_seq_length) {
    %seq_length = ();
    while (<$compliantFasta_dir_for_calculating_seq_length/*.fasta>) {
        chomp;
        my $species;
        if (/(\w+).fasta/) {
            $species = $1;
        }

        print STDERR "reading $_\n";
        open IN, $_ or die $!;
        my $seq_id;
        while (<IN>) {
            chomp;
            if (/>(\S+)/) { $seq_id = $1; }
            else {
                $seq_length{$species}{$seq_id} += length($_);
            }
        }
    }
}

my %filterred_seq_length;
my ($groupNum, $num_total, $num_filter_high_copy_num, $num_filter_fewer_species_ratio, $num_filter_only_paralog_group, $num_filter_opc, $num_filter_fewer_single_species_ratio) = (0, 0, 0, 0, 0, 0, 0);
open IN, $ARGV[0] or die "Can not open file $ARGV[0], $!";
while (<IN>) {
    $num_total ++;
    my $group = $1 if s/^([^:]+?):\s+?//;
    s/\s*$//;
    my @sequences = split /\s+/, $_;
    if (@sequences > $species_num * $copy_num) {
		my $bbb = @sequences;
        $num_filter_high_copy_num ++;
        next;
    }
    if (@sequences < $species_num * $species_ratio) {
        $num_filter_fewer_species_ratio ++;
        next;
    }

    my (%species, @seq_length);
    foreach (@sequences) {
        if (m/([^\s\|]+)\|/) {
            $species{$1}{$_} = 1;
            push @seq_length, $seq_length{$1}{$_};
        }
    }
    my $single_species_num = 0;
    foreach (keys %species) {
        my @species_num = keys %{$species{$_}};
        $single_species_num ++ if @species_num == 1;
    }
    unless (keys %species >= $species_num * $species_ratio) {
        $num_filter_fewer_species_ratio ++;
        next;
    }
	my @species_number = keys %species;
    unless ($single_species_num >= $single_copy_species_ratio * @species_number) {
        $num_filter_fewer_single_species_ratio ++;
        next;
    }
    if (keys %species < 2) {
        $num_filter_only_paralog_group ++;
        next;
    }

    if ($ortholog_picking_config) {
        my $keep = 1;
        foreach (keys %opc) {
            my $num_threshold = $opc{$_};
            my @target_species = split /[,;]/, $_;
            my $target_num = 0;
            foreach (@target_species) {
                warn "The target speices $_ was not correct\n" unless exists $species_name{$_};
                $target_num ++ if exists $species{$_};
            }
            $keep = 0 if $target_num < $num_threshold;
        }
        if ($keep != 1) {
            $num_filter_opc ++;
            next;
        }
    }

    @seq_length = sort {$a <=> $b} @seq_length;
    if ($seq_length[0] > $max_seq_length) {
        $filterred_seq_length{$group} = $seq_length[0];
        next;
    }

    $groupNum ++;
    if ($out_tab_for_CAFE) {
        my %species_num;
        foreach (@species) {
            my $gene_num = 0;
            if (exists $species{$_}) {
                my @genes = keys %{$species{$_}};
                $gene_num = @genes;
            }
            $species_num{$_} = $gene_num;
        }
        my $output .= "\t$group";
        foreach (@species) {
            $output .= "\t$species_num{$_}";
        }
        print OUT_CAFE "$output\n";
    }

    open OUT, '>', "$out_directory/$group.fasta" or die "Can not create file $out_directory/$group.fasta, $!";

    foreach (sort keys %species) {
        my @sequenceId = sort {$seq_length{$_}{$b} <=> $seq_length{$_}{$a}} keys %{$species{$_}};
        print OUT ">$sequenceId[0]\n$fasta{$_}{$sequenceId[0]}\n";
    }
}
close IN;

if ($out_tab_for_CAFE) {
    close OUT_CAFE;
}

my @filterred_seq_length = keys %filterred_seq_length;
my $filterred_seq_length_num = @filterred_seq_length;
my $filterred_seq_length_info = join ",", @filterred_seq_length;
print STDERR "Total Groups Number: $num_total\n";
print STDERR "The number of Groups filterred by High copy number: $num_filter_high_copy_num\n";
print STDERR "The number of Groups filterred by Low species ratio: $num_filter_fewer_species_ratio\n";
print STDERR "The number of Groups filterred by Low single species ratio: $num_filter_fewer_single_species_ratio\n";
print STDERR "The number of Groups filterred for only paralog group: $num_filter_only_paralog_group\n";
print STDERR "The number of Groups filterred by Ortholog picking config: $num_filter_opc\n";
print STDERR "The number of Groups filterred by Long sequence length > $max_seq_length: $filterred_seq_length_num\n";
print STDERR "The Groups with Long sequence length: $filterred_seq_length_info\n" if $filterred_seq_length_info;
print STDERR "$groupNum valid Ortholog Groups were found!\n";
