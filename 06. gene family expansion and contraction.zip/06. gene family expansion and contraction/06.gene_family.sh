#get the candidate gene families for cafe analysis 
orthomcl_extract_ortholog_seqs.pl --out_directory outdiectory --out_tab_for_CAFE orthomcl2cafe.tab --species_ratio 0.5 --single_copy_species_ratio 0.0 --copy_num 1000 --max_seq_length 50000 all.orthogroups.id.txt CDS_Seq_Directory

#echo '#!/public/users/liuqiong/14.genome_comparison/biosoft/CAFE-4.2.1/bin/cafe
#version
#date


#load -i orthomcl2cafe.tab -t 24 -p 0.01
#tree (((((bryot,teurt),(ditin,ledel)),(((depte,psovi),sasca),(hyruf,stmag))),(((degal,(trmer,(vades,vajac))),meocc),ixsca)),stmim);  #here is an example, divergence time must be added when do the real sample test.

#lambda -s
#report out' > cafe_command



./cafe_command
#deal with the result
parsing_cafeOut.pl out.cafe