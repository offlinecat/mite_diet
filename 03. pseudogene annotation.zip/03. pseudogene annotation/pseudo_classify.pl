#!/usr/bin/perl -w
use strict;
use Getopt::Long;
##explanation:this program is edited to find the pseudogenes from genewise result.
##edit by liuq;   Tue Jun 16 09:30:08 CST 2020

my $usage = <<USAGE;
#Usage:

  perl  $0 [options] genewise.gff.out

USAGE

die $usage unless (@ARGV ==1);


open (IA,"$ARGV[0]") || die "input file can't open $!";

$/="See WWW help for more info"; 
(<>);
while(<IA>)
          {
                	chomp ;
			my @inf=split /\/\//,$_;
                        @aa=split /\n/,$inf[1];
                        print $aa[2],"\t";
			if($inf[0]=~/\!/ && $inf[0]=~/X/ && $inf[0]!~/XX/)
			{
				print "pseudogne_Both","\n";
			} 
			elsif($inf[0]=~/\!/)
			{
				print "pseudogene_snv","\n";
			}
			elsif($inf[0]=~/X/ && $inf[0]!~/XX/)
			{
				print "pseudogne_terminal","\n";
			}
			else
			{
				print "null\n";
			}
	}

close IA;
