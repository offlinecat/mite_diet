#!/usr/bin/perl
use strict;

my $usage = <<USAGE;
Usage:
    $0 proteinAlignment.fasta CDS_nonAligned.fasta > CodonAlignment.fasta

    程序用于将蛋白序列的比对结果转化为密码子序列比对结果。要求输入的CDS序列的第一个字符必须是密码子的第一位，否则可能导结果中某些序列第一个碱基不是密码子第一位，则多序列比对结果是错误的。若输入的CDS序列长度不是3的倍数，一般是转录本3'端缺失造成的，程序会将CDS序列尾部多余的1~2个碱基去除后再进行分析。程序最后会检测CDS序列长度是否是蛋白序列长度的3倍，若不是的话，程序会强行结束，得不到结果。
    输入的proteinAlignment.fasta文件中的GAP必须使用字符 - 表示，对应结果文件中变换为 --- 三个中划线字符。
    此外，若proteinAlignment.fasta种出现 X 字符，且对应的CDS中的序列为终止密码子，则X字符变换为 --- 三个中划线字符。因此，推荐在对蛋白序列进行多序列比对前，将 * 字符变更为 X 字符，以免 Mafft 多序列比对软件会直接去除 * 字符，让比对结果不准确；同时也有利于将蛋白序列比对结果转化为密码子序列比对结果时，Codon序列中不会出现终止密码子。若Codon序列中出现终止密码子，则使用PAML软件进行正选择分析时报错。

USAGE
if (@ARGV==0){die $usage}

# 读取proteinAlignment.fasta文件
open IN, $ARGV[0] or die "Can not open file $ARGV[0], $!";
my (%proteinSeq, $seq_id);
while (<IN>) {
    chomp;
    if (m/^>(\S+)/) { $seq_id = $1; }
    else { $proteinSeq{$seq_id} .= $_; }
}
close IN;

# 读取CDS_nonAligned.fasta文件
open IN, $ARGV[1] or die "Can not open file $ARGV[1], $!";
my (%cdsSeq, $seq_id);
while (<IN>) {
    chomp;
    if (m/^>(\S+)/) { $seq_id = $1; }
    else { $cdsSeq{$seq_id} .= $_; }
}
close IN;

my %cdsAligned;
my %stop_codon = ("TAA", 1, "TAG", 1, "TGA", 1);
foreach my $id (keys %proteinSeq) {
    my $seq_protein = $proteinSeq{$id};
    die "The CDS sequence of $id can not find in file $ARGV[1].\n" unless exists $cdsSeq{$id};
    my $seq_cds = $cdsSeq{$id};
    my $more = length($seq_cds) % 3;
    if ($more > 0) {
        $seq_cds =~ s/\w{$more}$//;
    }

    my $num = 0;
    my @seq_protein = split //, $seq_protein;
    foreach (@seq_protein) {
        $num ++;
        if ($_ ne '-') {
            if ($seq_cds =~ s/(\w\w\w)//) {
                if ($_ eq 'X' && (exists $stop_codon{$1})) {
                    $cdsAligned{$id} .= '---';
                }
                else {
                    $cdsAligned{$id} .= $1;
                }
            }
            else {
                die "The CDS sequence length of $id < its protein length * 3.\n";
            }
        }
        else {
            $cdsAligned{$id} .= '---';
        }
    }

    if (length($seq_cds) == 3) {
        if (exists $stop_codon{$seq_cds}) {
            $seq_cds = "";
        }
    }
    if (length($seq_cds) != 0) {
        die "The CDS sequence length of $id > its protein length * 3.\n";
    }
}

foreach (sort keys %cdsAligned) {
    print ">$_\n$cdsAligned{$_}\n";
}
