#get the single-copy orthologous gene
orthomcl_extract_ortholog_seqs.pl --out_directory out.CDS.directory --species_ratio 1 --single_copy_species_ratio 1 --copy_num 1 --max_seq_length 100000 Orthogroups.txt Orthologous_CDS_Seq_Directory/

orthomcl_extract_ortholog_seqs.pl --out_directory orthologGroups_Protein --species_ratio 1 --single_copy_species_ratio 1 --copy_num 1 --max_seq_length 100000 --compliantFasta_dir_for_calculating_seq_length  Orthologous_CDS_Seq_Directory/ Orthogroups.txt Orthologous_Protein_Seq_Directory/


#do sequence alignment and here 00001 is the orthologous gene id
linsi orthologGroups_Protein/00001.fasta > orthologGroups_Protein/00001.fasta.align


#Protein alignment to CDS alignment
proteinAlignment2CDSAlignemnt.pl orthologGroups_Protein/00001.fasta.align orthologGroups_CDS/00001.fasta > orthologGroups_CDS/00001.fasta.align