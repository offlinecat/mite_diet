#!/bin/bash

RepeatMasker -e ncbi -species Arachnida -gff -pa 24 -dir RM_tmp -qq src_genome.fasta
ln -s RM_tmp/src_genome.fasta.masked genome.fasta
echo "repeatmasker finished"

#braker main pipe
echo "start braker main function"
rm -rf /public/users/liuqiong/.conda/envs/liuqiong/config/species/sample
braker.pl --species=sample --genome=genome.fasta --prot_seq=homolog.fasta --prg=gth --trainFromGth
date
echo "braker main function complete"

#result process
perl -e 'while (<>) { if (m/\tCDS\t/) { print; s/\tCDS\t/\texon\t/; print; } elsif (m/\ttranscript\t/) { next; } elsif (m/^#/) { next; } elsif (m/\tgene\t/) { next; } elsif (m/\tintron\t/) { next; } else { print; } }' braker/sample/augustus.hints.gtf > braker.gtf
PASApipeline-v2.3.3/misc_utilities/gtf_to_gff3_format.pl braker.gtf genome.fasta > braker.gff3
gtf2gff3.pl braker.gtf > braker.gff3
gff3_clear.pl --prefix braker braker.gff3 > aa; mv aa braker.gff3
date
echo "completed"
